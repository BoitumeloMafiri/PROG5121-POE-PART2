/*
 * Main class - Registration and Login application
 * PROG5121 - Programming 1A PART 2
 * Boitumelo Mafiri - ST10106738
 */
package assignment.pkg1.first.year;
 
import java.util.Scanner;
 
/**
 * This is the main class that runs the Registration, Login,
 * and QuickChat messaging system.
 *
 * @author ST10106738
 */
public class ChatApp {
 
    // Track total messages sent across the session
    private static int totalMessagesSent = 0;
 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();
 
        // ========== Registration and Login (Part 1) ==========
        boolean loggedIn = false;
 
        while (!loggedIn) {
            System.out.println("\n===== Welcome to QuickChat! =====");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume leftover newline
 
            switch (choice) {
                case 1:
                    // --- Registration ---
                    System.out.print("Enter first name: ");
                    login.setFirstName(scanner.nextLine());
                    System.out.print("Enter last name: ");
                    login.setLastName(scanner.nextLine());
                    System.out.print("Enter username: ");
                    login.setUsername(scanner.nextLine());
                    System.out.print("Enter password: ");
                    login.setPassword(scanner.nextLine());
                    System.out.print("Enter SA cell phone number (e.g. +27838968976): ");
                    login.setCellPhoneNumber(scanner.nextLine());
 
                    String result = login.registerUser();
                    System.out.println("\n" + result);
                    break;
 
                case 2:
                    // --- Login ---
                    System.out.print("Enter username: ");
                    login.setUsername(scanner.nextLine());
                    System.out.print("Enter password: ");
                    login.setPassword(scanner.nextLine());
 
                    String status = login.returnLoginStatus();
                    System.out.println("\n" + status);
 
                    if (login.loginUser()) {
                        loggedIn = true;
                    }
                    break;
 
                case 3:
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;
 
                default:
                    System.out.println("Invalid option, please try again.");
                    break;
            }
        }
 
        // --- QuickChat Messaging (Part 2) ---
        System.out.println("\nWelcome to QuickChat.");
        runMessageSystem(scanner);
 
        scanner.close();
    }
 
    /**
     * Runs the QuickChat main menu loop.
     * Users can send messages, view recently sent (coming soon), or quit.
     *
     * @param scanner shared Scanner for reading user input
     */
    public static void runMessageSystem(Scanner scanner) {
        boolean keepRunning = true;
 
        while (keepRunning) {
            System.out.println("\n===== QuickChat Menu =====");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline
 
            switch (choice) {
                case 1:
                    sendMessages(scanner);
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    keepRunning = false;
                    System.out.println("Goodbye!");
                    System.out.println("Total messages sent: " + totalMessagesSent);
                    break;
                default:
                    System.out.println("Invalid option, please try again.");
                    break;
            }
        }
    }
 
    /**
     * Handles sending multiple messages in a loop.
     * Each message is validated, hashed, and the user chooses to
     * send, disregard, or store it.
     *
     * @param scanner shared Scanner for reading user input
     */
    public static void sendMessages(Scanner scanner) {
        System.out.print("How many messages would you like to send? ");
        int numMessages = scanner.nextInt();
        scanner.nextLine();
 
        for (int i = 0; i < numMessages; i++) {
            int messageNum = i + 1;
            Message msg = new Message(messageNum);
 
            // --- Get and validate recipient ---
            System.out.print("\nEnter recipient cell number (e.g. +27838968976): ");
            msg.setRecipient(scanner.nextLine());
 
            String cellStatus = msg.checkRecipientCell();
            System.out.println(cellStatus);
 
            if (!cellStatus.contains("successfully")) {
                i--; // retry this message
                continue;
            }
 
            // --- Get and validate message content ---
            System.out.print("Enter your message (max 250 characters): ");
            msg.setMessageContent(scanner.nextLine());
 
            String lengthStatus = msg.checkMessageLength();
            System.out.println(lengthStatus);
 
            if (!lengthStatus.equals("Message ready to send.")) {
                i--; // retry this message
                continue;
            }
 
            // --- Generate the hash ---
            msg.createMessageHash();
 
            // --- Ask user what to do with the message ---
            System.out.println("\nWhat do you want to do with this message?");
            System.out.println("1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. Store Message");
            System.out.print("Choose an option: ");
            int action = scanner.nextInt();
            scanner.nextLine();
 
            switch (action) {
                case 1:
                    totalMessagesSent++;
                    System.out.println("\n" + msg.printMessageDetails());
                    System.out.println("Message successfully sent.");
                    break;
                case 2:
                    System.out.println("Press 0 to delete the message.");
                    break;
                case 3:
                    msg.storeMessage();
                    System.out.println("Message successfully stored.");
                    break;
                default:
                    System.out.println("Invalid choice. Message not processed.");
                    break;
            }
        }
 
        System.out.println("\nTotal messages sent this round: " + totalMessagesSent);
    }
}