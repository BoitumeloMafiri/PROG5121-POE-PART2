/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
/*
 * Message class - handles message creation, validation, and storage
 * PROG5121 - Programming 1A PART 2
 */
package assignment.pkg1.first.year;
 
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
 
/**
 * This class creates and validates messages, generates message hashes,
 * and stores messages in a JSON file when requested.
 *
 * @author ST10106738
 */
public class Message {
 
    // Message fields
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageContent;
    private String messageHash;
 
    // Constructor
    public Message(int messageNumber) {
        this.messageID = generateMessageID();   // auto-generate 10-digit ID
        this.messageNumber = messageNumber;     // sent from the loop counter
        this.recipient = "";
        this.messageContent = "";
        this.messageHash = "";
    }
 
    // --- Setters ---
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }
 
    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }
 
    // --- Getters ---
    public String getMessageID() {
        return messageID;
    }
 
    public int getMessageNumber() {
        return messageNumber;
    }
 
    public String getRecipient() {
        return recipient;
    }
 
    public String getMessageContent() {
        return messageContent;
    }
 
    public String getMessageHash() {
        return messageHash;
    }
 
    /**
     * Generates a random 10-digit message ID.
     * Uses String.format to pad shorter numbers with leading zeros.
     *
     * @return a 10-digit message ID as a String
     */
    private String generateMessageID() {
        Random rand = new Random();
        long id = (long) (rand.nextDouble() * 9000000000L) + 1000000000L;
        return String.valueOf(id);
    }
 
    /**
     * Checks if the message ID is no more than 10 characters.
     *
     * @return true if valid, false otherwise
     */
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }
 
    /**
     * Checks if the recipient cell number is no more than 10 characters
     * and contains the international country code (+27).
     * Pattern source: regex pattern researched and tested at
     * https://regexr.com — adapted from SA cell number validation examples.
     *
     * @return success or failure message
     */
    public String checkRecipientCell() {
        if (recipient.matches("^\\+27\\d{9}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain "
                    + "an international code. Please correct the number and try again.";
        }
    }
    
    /**
     * Builds the message hash a short ID that represents this message.
     * 
     * The hash has 3 parts joined with colons:
     * 1. The first 2 digits of the message ID
     * 2. The message number (1st message, 2nd message, etc.)
     * 3. The first word + last word of the message, all in CAPS
     * 
     * Example: if the message is "Hi Mike, dinner tonight?" and it's message #0,
     * the hash becomes:  00:0:HITONIGHT
     *
     * @return the hash as a String
     */
    
    public String createMessageHash() {
        String first2 = messageID.substring(0, 2);
 
        // Split the message into words by spaces
        String[] words = messageContent.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^a-zA-Z]", "");
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z]", "");
 
        String wordPart = (firstWord + lastWord).toUpperCase();
        this.messageHash = first2 + ":" + messageNumber + ":" + wordPart;
        return messageHash;
    }
 
    /**
     * Checks if the message is no more than 250 characters.
     *
     * @return success message or error message with the excess count
     */
    public String checkMessageLength() {
        if (messageContent.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = messageContent.length() - 250;
            return "Message exceeds 250 characters by " + excess
                    + ", please reduce the size.";
        }
    }
 
    /**
     * Stores the message to a JSON file (Jsonnew.json) in append mode.
     * Each message is written as a JSON object entry.
     */
    public void storeMessage() {
        StringBuilder jsonEntry = new StringBuilder();
        jsonEntry.append("{\n");
        jsonEntry.append("  \"MessageID\": \"").append(messageID).append("\",\n");
        jsonEntry.append("  \"MessageNumber\": ").append(messageNumber).append(",\n");
        jsonEntry.append("  \"MessageHash\": \"").append(messageHash).append("\",\n");
        jsonEntry.append("  \"Recipient\": \"").append(recipient).append("\",\n");
        // Escape any double-quotes inside the message content
        jsonEntry.append("  \"Message\": \"")
                 .append(messageContent.replace("\"", "\\\""))
                 .append("\"\n");
        jsonEntry.append("},\n");
 
        try (FileWriter file = new FileWriter("Jsonnew.json", true)) {
            file.write(jsonEntry.toString());
        } catch (IOException e) {
            System.out.println("Error writing to JSON file: " + e.getMessage());
        }
    }
 
    /**
     * Returns the full details of this message as a formatted string.
     * Order: Message ID, Message Hash, Recipient, Message.
     *
     * @return message details as a printable string
     */
    public String printMessageDetails() {
        return "Message ID: " + messageID + "\n"
             + "Message Hash: " + messageHash + "\n"
             + "Recipient: " + recipient + "\n"
             + "Message: " + messageContent;
    }
}