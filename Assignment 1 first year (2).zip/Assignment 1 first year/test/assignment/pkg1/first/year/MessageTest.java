/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
 * Unit tests for the Message class
 * PROG5121 - Programming 1A PART 2
 */
package assignment.pkg1.first.year;
 
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
 
/**
 * Tests for message creation, validation, hashing, and storage.
 *
 * @author ST10106738
 */
public class MessageTest {
 
    private Message message;
 
    @Before
    public void setUp() {
        message = new Message(0); // first message in the array
    }
 
    // ========== Checking That Results Match ==========
 
    // Test: Message ID is no more than 10 chars returns true
    @Test
    public void testCheckMessageID_ReturnsTrue() {
        assertTrue(message.checkMessageID());
    }
 
    // Test: Recipient correctly formatted returns success message
    @Test
    public void testCheckRecipientCell_CorrectFormat_ReturnsSuccess() {
        message.setRecipient("+27838968976");
        String result = message.checkRecipientCell();
        assertEquals("Cell phone number successfully captured.", result);
    }
 
    // Test: Recipient incorrectly formatted returns error message
    @Test
    public void testCheckRecipientCell_IncorrectFormat_ReturnsError() {
        message.setRecipient("08966553");
        String result = message.checkRecipientCell();
        String expected = "Cell phone number is incorrectly formatted or does not contain "
                + "an international code. Please correct the number and try again.";
        assertEquals(expected, result);
    }
 
    // Test: check that the message hash is built in the right format
    // Expected result: starts with 2 ID digits, then ":0:" (message number), then HITONIGHT
    @Test
    public void testCreateMessageHash_FormatCorrect() {
        message.setMessageContent("Hi Mike, can you join us for dinner tonight?");
        String hash = message.createMessageHash();
 
        // Hash must contain ":0:" because messageNumber is 0
        assertTrue(hash.contains(":0:"));
        // Hash must end with HITONIGHT (uppercase first + last word, punctuation stripped)
        assertTrue(hash.endsWith("HITONIGHT"));
    }
 
    // Test: Message under 250 characters returns ready message
    @Test
    public void testCheckMessageLength_UnderLimit_ReturnsReady() {
        message.setMessageContent("Hi Mike, can you join us for dinner tonight?");
        String result = message.checkMessageLength();
        assertEquals("Message ready to send.", result);
    }
 
    // Test: Message over 250 characters returns error with excess count
    @Test
    public void testCheckMessageLength_OverLimit_ReturnsError() {
        // Build a 260-character message (10 chars over the limit)
        StringBuilder longMsg = new StringBuilder();
        for (int i = 0; i < 260; i++) {
            longMsg.append("a");
        }
        message.setMessageContent(longMsg.toString());
 
        String result = message.checkMessageLength();
        assertTrue(result.contains("exceeds 250 characters by 10"));
    }
 
    // ========== Checking Message Details ==========
 
    // Test: Message details contain all required fields
    @Test
    public void testPrintMessageDetails_ContainsAllFields() {
        message.setRecipient("+27838968976");
        message.setMessageContent("Hi Mike, can you join us for dinner tonight?");
        message.createMessageHash();
 
        String details = message.printMessageDetails();
        assertTrue(details.contains("Message ID:"));
        assertTrue(details.contains("Message Hash:"));
        assertTrue(details.contains("Recipient: +27838968976"));
        assertTrue(details.contains("Hi Mike"));
    }
 
    // Test: Getters return correct values
    @Test
    public void testGetters_ReturnCorrectValues() {
        message.setRecipient("+27718693002");
        message.setMessageContent("Test message");
 
        assertEquals("+27718693002", message.getRecipient());
        assertEquals("Test message", message.getMessageContent());
        assertEquals(0, message.getMessageNumber());
        assertNotNull(message.getMessageID());
    }
}