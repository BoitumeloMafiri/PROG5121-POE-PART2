/*
 * Unit tests for the Login class
 * PROG5121 - Programming 1A PART2
 */
package assignment.pkg1.first.year;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 * Tests for registration and login functionality.
 *
 * @author ST10106738
 */


public class LoginTest {

    private Login login;

    @Before
    public void setUp() {
        login = new Login();
        login.setFirstName("Kyle");
        login.setLastName("Smith");
    }

    // ========== Checking That Results Match ==========

    // Test: username correctly formatted, full flow returns welcome message
    @Test
    public void testUsernameCorrectlyFormatted_ReturnsWelcome() {
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setCellPhoneNumber("+27838968976");
        login.registerUser();

        // After successful registration, login with same credentials
        String expected = "Welcome Kyle, Smith it is great to see you again.";
        assertEquals(expected, login.returnLoginStatus());
    }

    // Test: username incorrectly formatted, returns error message
    @Test
    public void testUsernameIncorrectlyFormatted_ReturnsError() {
        login.setUsername("kyle!!!!!!!");
        login.setPassword("Ch&&sec@ke99!");
        login.setCellPhoneNumber("+27838968976");

        String result = login.registerUser();
        String expected = "Username is not correctly formatted, "
                + "please ensure that your username contains an underscore "
                + "and is no more than five characters in length.";
        assertEquals(expected, result);
    }

    // Test: password meets complexity, returns success message
    @Test
    public void testPasswordMeetsComplexity_ReturnsSuccess() {
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setCellPhoneNumber("+27838968976");

        String result = login.registerUser();
        assertTrue(result.contains("Password successfully captured."));
    }

    // Test: password does not meet complexity, returns error message
    @Test
    public void testPasswordDoesNotMeetComplexity_ReturnsError() {
        login.setUsername("kyl_1");
        login.setPassword("password");
        login.setCellPhoneNumber("+27838968976");

        String result = login.registerUser();
        String expected = "Password is not correctly formatted, "
                + "please ensure that the password contains at least eight characters, "
                + "a capital letter, a number, and a special character.";
        assertEquals(expected, result);
    }

    // Test: cell phone correctly formatted, returns success message
    @Test
    public void testCellPhoneCorrectlyFormatted_ReturnsSuccess() {
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setCellPhoneNumber("+27838968976");

        String result = login.registerUser();
        assertTrue(result.contains("Cell phone number successfully added."));
    }

    // Test: cell phone incorrectly formatted, returns error message
    @Test
    public void testCellPhoneIncorrectlyFormatted_ReturnsError() {
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setCellPhoneNumber("08966553");

        String result = login.registerUser();
        String expected = "Cell phone number is incorrectly formatted or does not contain "
                + "an international code, please correct the number and try again.";
        assertEquals(expected, result);
    }

    // ========== Checking True and False Results ==========

    // Test: login is successful, returns true
    @Test
    public void testLoginSuccessful_ReturnsTrue() {
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setCellPhoneNumber("+27838968976");
        login.registerUser();

        // Login with the same credentials
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        assertTrue(login.loginUser());
    }

    // Test: login fails, returns false
    @Test
    public void testLoginFailed_ReturnsFalse() {
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setCellPhoneNumber("+27838968976");
        login.registerUser();

        // Login with wrong credentials
        login.setUsername("kyl_1");
        login.setPassword("wrongPassword1!");
        assertFalse(login.loginUser());
    }

    // Test: username is correctly formatted returns true
    @Test
    public void testCheckUserName_CorrectFormat_ReturnsTrue() {
        login.setUsername("kyl_1");
        assertTrue(login.checkUserName());
    }

    // Test: username is incorrectly formatted returns false
    @Test
    public void testCheckUserName_IncorrectFormat_ReturnsFalse() {
        login.setUsername("kyle!!!!!!!");
        assertFalse(login.checkUserName());
      
    }
    
    // Test: wrong password returns error message
    @Test
    public void testLoginFailed() {
    login.setUsername("kyl_1");
    login.setPassword("wrongPassword1!");
    String result = login.returnLoginStatus();
    assertEquals("Username or password incorrect, please try again.", result);
    }
}

